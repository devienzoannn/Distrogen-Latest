from gui.app import App
App().mainloop()
