Please open issues on https://github.com/plougher/squashfs-tools/issues
